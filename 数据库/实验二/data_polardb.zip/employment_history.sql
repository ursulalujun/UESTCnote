

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (102, '1993-01-13','1998-07-24',  'IT_PROG', 60);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (101, '1989-09-21', '1993-10-27', 'AC_ACCOUNT', 110);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (101, '1993-10-28', '1997-03-15',  'AC_MGR', 110);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (201, '1996-02-17', '1999-12-17','MK_REP', 20);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (114, '1998-03-24', '1999-12-31', 'ST_CLERK', 50);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (122, '1999-01-01','1999-12-31', 'ST_CLERK', 50);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (200, '1987-09-17','1993-06-17', 'AD_ASST', 90);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (176, '1998-03-24','1999-12-31', 'SA_REP', 80);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (176, '1999-01-01','1999-12-31', 'SA_MAN', 80);

insert into employment_history (staff_id,start_date, end_date, employment_id, section_id)values (200, '1994-07-01','1998-12-31', 'AC_ACCOUNT', 90);





