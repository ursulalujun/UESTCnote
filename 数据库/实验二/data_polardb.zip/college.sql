
insert into college (college_id, college_name)values (1001, 'The University of Melbourne');

insert into college (college_id, college_name)values (1002, 'Duke University');

insert into college (college_id, college_name)values (1003, 'New York University');

insert into college (college_id, college_name)values (1004, 'Kings College London');

insert into college (college_id, college_name)values (1005, 'Tsinghua University');

insert into college (college_id, college_name)values (1006, 'University of Zurich');

insert into college (college_id, college_name)values (1007, 'Rice University');

insert into college (college_id, college_name)values (1008, 'Boston University');

insert into college (college_id, college_name)values (1009, 'Peking University');

insert into college (college_id, college_name)values (1010, 'Monash University');

insert into college (college_id, college_name)values (1011, 'KU Leuven');

insert into college (college_id, college_name)values (1012, 'University of Basel');

insert into college (college_id, college_name)values (1013, 'Leiden University');

insert into college (college_id, college_name)values (1014, 'Erasmus University');

insert into college (college_id, college_name)values (1015, 'Ghent University');

insert into college (college_id, college_name)values (1016, 'Aarhus University');
