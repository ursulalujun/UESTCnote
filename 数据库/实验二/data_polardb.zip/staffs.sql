
insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (198, 'Donald', 'OConnell', 'DOCONNEL', '650.507.9833', '1999-06-21', 'SH_CLERK', 2600.00, null, 124, 50);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (199, 'Douglas', 'Grant', 'DGRANT', '650.507.9844', '2000-01-13', 'SH_CLERK', 2600.00, null, 124, 50);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (200, 'Jennifer', 'Whalen', 'JWHALEN', '515.123.4444', '1987-09-17', 'AD_ASST', 4400.00, null, 101, 10);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (201, 'Michael', 'Hartstein', 'MHARTSTE', '515.123.5555','1996-02-17', 'MK_MAN', 13000.00, null, 100, 20);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (202, 'Pat', 'Fay', 'PFAY', '603.123.6666', '1997-08-17',
'MK_REP', 6000.00, null, 201, 20);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (203, 'Susan', 'Mavris', 'SMAVRIS', '515.123.7777', '1994-06-07', 'HR_REP', 6500.00, null, 101, 40);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (204, 'Hermann', 'Baer', 'HBAER', '515.123.8888', '1994-06-07', 'PR_REP', 10000.00, null, 101, 70);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (205, 'Shelley', 'Higgins', 'SHIGGINS', '515.123.8080', '1994-06-07', 'AC_MGR', 12000.00, null, 101, 110);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (206, 'William', 'Gietz', 'WGIETZ', '515.123.8181', '1994-06-07', 'AC_ACCOUNT', 8300.00, null, 205, 110);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (100, 'Steven', 'King', 'SKING', '515.123.4567', '1987-06-17',
'AD_PRES', 24000.00, null, null, 90);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (101, 'Neena', 'Kochhar', 'NKOCHHAR', '515.123.4568', '1989-09-21', 'AD_VP', 17000.00, null, 100, 90);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (102, 'Lex', 'De Haan', 'LDEHAAN', '515.123.4569', '1993-01-13', 'AD_VP', 17000.00, null, 100, 90);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (103, 'Alexander', 'Hunold', 'AHUNOLD', '590.423.4567', '1990-01-03', 'IT_PROG', 9000.00, null, 102, 60);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (104, 'Bruce', 'Ernst', 'BERNST', '590.423.4568', '1991-05-21', 'IT_PROG', 6000.00, null, 103, 60);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (105, 'David', 'Austin', 'DAUSTIN', '590.423.4569', '1997-06-25', 'IT_PROG', 4800.00, null, 103, 60);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (106, 'Valli', 'Pataballa', 'VPATABAL', '590.423.4560', '1998-02-05', 'IT_PROG', 4800.00, null, 103, 60);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (107, 'Diana', 'Lorentz', 'DLORENTZ', '590.423.5567', '1999-02-07', 'IT_PROG', 4200.00, null, 103, 60);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id) values (108, 'Nancy', 'Greenberg', 'NGREENBE', '515.124.4569', '1994-08-17', 'FI_MGR', 12000.00, null, 101, 100);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (109, 'Daniel', 'Faviet', 'DFAVIET', '515.124.4169', '1994-08-16', 'FI_ACCOUNT', 9000.00, null, 108, 100);

insert into staffs (staff_id, first_name, last_name, email, phone_number, hire_date,employment_id, salary, commission_pct, manager_id, section_id)values (110, 'John', 'Chen', 'JCHEN', '515.124.4269', '1997-09-28',
'FI_ACCOUNT', 8200.00, null, 108, 100);
