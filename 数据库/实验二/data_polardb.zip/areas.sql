
insert into areas (area_id, area_name)
values (1, 'Europe');

insert into areas (area_id, area_name)
values (2, 'Americas');

insert into areas (area_id, area_name)
values (3, 'Asia');

insert into areas (area_id, area_name)
values (4, 'Middle East and Africa');
